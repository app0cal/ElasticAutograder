public class Fibonacci {
    public static long value(int n) {
        return -1;
    }
}
