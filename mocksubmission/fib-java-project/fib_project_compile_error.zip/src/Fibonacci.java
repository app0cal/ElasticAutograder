public class Fibonacci {
    public static long value(int n) {
        return missingSymbol;
    }
}
