public class Fibonacci {
    public static long value(int n) {
        throw new IllegalStateException("intentional runtime failure");
    }
}
